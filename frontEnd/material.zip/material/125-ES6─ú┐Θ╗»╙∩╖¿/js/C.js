/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
A_A()
B_B()


function C(){
    console.log("CC")
}

