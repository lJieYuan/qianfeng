/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
function B1(){
    _b_common()
    console.log("B1-布局创建")
}



function B2(){
    _b_common()
    console.log("B2-布局创建")
}


function _b_common(){
    console.log("b_common")
}

function test(){
    console.log("B1-test")
}

function B_B(){
    console.log("B_B")
}

export {
    B1,
    B2,
    test,
    B_B
}