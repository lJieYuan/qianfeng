/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
var $  = {
    a(){

    },

    ajax(){
        console.log("kerwin-ajax")
    }
}


var jQuery = {
    b:1
}